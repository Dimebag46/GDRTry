﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

    public float moveSpeed;
    private float moveVelocity;
    public float maxSpeed=3;
    public float jumpHeight;
    

    public Transform groundCheck;
    public float groundCheckRadius;
    public LayerMask whatIsGround;
    private bool grounded;


    private bool doubleJumped;

    private Animator anim;

    public float knockback;
    public float knockbackLenght;
    public float knockbackCounter;
    public bool knockRight;


  
    void Start ()
    {
        anim = GetComponent<Animator>();
    }

    void FixedUpdate()
    {
         grounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, whatIsGround);
       
    }

    
    void Update () {

     
        // MOVIMENTO

        moveVelocity = 0f;

        if (Input.GetKey(KeyCode.D))
        { 
            moveVelocity = moveSpeed;
        }
        
        if (Input.GetKey(KeyCode.A))
        {
            moveVelocity = -moveSpeed;
        }

        // KNOCKBACK
        if (knockbackCounter <= 0)
        { GetComponent<Rigidbody2D>().velocity = new Vector2(moveVelocity, GetComponent<Rigidbody2D>().velocity.y); }
        else
        { if (knockRight)
          GetComponent<Rigidbody2D>().velocity = new Vector2(-knockback, knockback);
          if (!knockRight)
          GetComponent<Rigidbody2D>().velocity = new Vector2(knockback, knockback);
            knockbackCounter -= Time.deltaTime;
        }

        // SALTO
        if (grounded)
            doubleJumped = false;

        if (Input.GetKeyDown(KeyCode.Space) && grounded)
        { 
            Jump();
        }

        if (Input.GetKeyDown(KeyCode.Space) && !doubleJumped && !grounded)
        {        
            Jump();
            doubleJumped = true;
        }

        // ANIMAZIONE
        anim.SetFloat("Speed", Mathf.Abs(GetComponent<Rigidbody2D>().velocity.x));
        anim.SetBool("Grounded", grounded);

        // FLIP IMMAGINE
        if (Input.GetAxis("Horizontal") < -0.1f)
        { transform.localScale = new Vector3(-5, 5, 1); }
        if (Input.GetAxis("Horizontal") > 0.1f)
        { transform.localScale = new Vector3(5, 5, 1); }

    }

    // SALTO
    public void Jump()
    {

        GetComponent<Rigidbody2D>().velocity = new Vector2(GetComponent<Rigidbody2D>().velocity.x, jumpHeight);
    }

   

}
