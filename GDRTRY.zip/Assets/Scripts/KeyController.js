﻿#pragma strict

public var speed: float = 1f;


function Update () {
           
    var move = Vector3(Input.GetAxis("Horizontal"),0,0);
    transform.position += move * speed * Time.deltaTime;

    

    if(Input.GetAxis("Horizontal") < -0.1f)
    { transform.localScale = new Vector3 (-5, 5, 1); }
    if(Input.GetAxis("Horizontal") > 0.1f) 
    { transform.localScale = new Vector3 (5, 5, 1); }
}