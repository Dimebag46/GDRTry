﻿using UnityEngine;
using System.Collections;

public class GroundAppear : MonoBehaviour {

    public GameObject ground;

	// Use this for initialization
	void Start () {
        ground.GetComponent<SpriteRenderer>().enabled = false;
    }
	
	// Update is called once per frame
	void Update () {


    }

    void OnCollisionEnter2D(Collision2D coll) {

        if (coll.gameObject.name == "MarioFermo")
        {
            ground.GetComponent<SpriteRenderer>().enabled = true;
        }

    }
}
