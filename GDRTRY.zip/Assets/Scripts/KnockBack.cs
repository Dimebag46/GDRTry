﻿using UnityEngine;
using System.Collections;

public class KnockBack : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "MarioFermo")
        {
             var player = other.GetComponent<PlayerController>();
             player.knockbackCounter = player.knockbackLenght;

            /* if (other.transform.position.x < transform.position.x)
                 player.knockRight = true;
             else
                 player.knockRight = false;*/

        }
    }
}
