﻿using UnityEngine;
using System.Collections;

public class CoinsPick : MonoBehaviour {

    public int pointsToAdd;

    void OnTriggerEnter2D(Collider2D other)
    {
        ScoreManager.AddPoints(pointsToAdd);
        Destroy(gameObject);
    }

}
