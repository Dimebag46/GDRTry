﻿using UnityEngine;
using System.Collections;

public class Stomp : MonoBehaviour {

    public float bounce;

    private Rigidbody2D rigid;

	// Use this for initialization
	void Start () {
        rigid = transform.parent.GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            Destroy(GameObject.FindWithTag("Enemy"));
            rigid.velocity = new Vector2(rigid.velocity.x, bounce);
        }
    }

}
